import React from "react";
import LoginPage from "./loginPage/login";

const App = () => {
  return <LoginPage />;
};

export default App;
